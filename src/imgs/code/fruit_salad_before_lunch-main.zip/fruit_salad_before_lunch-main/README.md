# Fruit Salad App

## Installation and Usage

- cd into folder
- npm install
- npm run dev will run on [8080](http://localhost:8080/)
