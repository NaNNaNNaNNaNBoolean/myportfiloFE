const { extractFruit } = require("./fruit");
const fruitForm = document.querySelector("#inputSection form");

fruitForm.addEventListener("submit", extractFruit);

console.log("hello");
